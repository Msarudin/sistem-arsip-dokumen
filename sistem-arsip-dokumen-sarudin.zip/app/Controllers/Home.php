<?php

namespace App\Controllers;

class Home extends BaseController
{
    public function index(): string
    {
        $data = [
            'title' => 'M. Sarudin E - Sistem Arsip Dokumen'
        ];

        return view('home', $data);
    }
}
